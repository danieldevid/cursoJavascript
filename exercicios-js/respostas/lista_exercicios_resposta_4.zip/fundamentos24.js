function helloWorld () {
   let i = 0
    while (i < 11) {
        console.log("Hello World");
        i++
    }   
}

helloWorld()